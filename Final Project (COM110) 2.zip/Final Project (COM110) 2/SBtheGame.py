import pygame
import random
from button import *
from graphics import *
from snake import *
from food import *

def game():
    introWin = GraphWin("Welcome to SnakeBite",500,450)
    theme = Image(Point(250,245),"theme.png")
    theme.draw(introWin)

    proName = Text(Point(250,230),"SnakeBite")
    proName.setSize(50)
    proName.setTextColor(color_rgb(255, 240, 214))
    proName.setFace("courier")
    proName.setStyle("bold")
    proName.draw(introWin)

    bigSnake = Image(Point(310,210),"snake_head.png").draw(introWin)

    startButton = Button(introWin,Point(250,300),70,30,"START")
    quitButton = Button(introWin,Point(250,400),70,30,"QUIT")
    ruleButton = Button(introWin,Point(250,350),70,30,"RULES")

    pt = introWin.getMouse()

    while not quitButton.isClicked(pt):
        if startButton.isClicked(pt):
            introWin.close()
            main()
            break
        elif ruleButton.isClicked(pt):
            instruction()
        pt = introWin.getMouse()
    introWin.close()

def instruction():
    instructWin = GraphWin("Instruction",300,300)
    theme2 = Image(Point(150,190),"theme2.png")
    theme2.draw(instructWin)

    title = Text(Point(150,30),"INSTRUCTION")
    title.setSize(25)
    title.setStyle("bold")
    title.setFace("courier")
    title.setTextColor(color_rgb(255, 240, 214))
    title.draw(instructWin)

    bigSnake = Image(Point(245,29),"snake_head.png").draw(instructWin)
    bigSnake = Image(Point(58,29),"snake_head.png").draw(instructWin)
    

    
def main():
    def message(msg,color,x,y,font):
        text = font.render(msg,True,color)
        text_rect = text.get_rect(center=(x,y))
        gameDisplay.blit(text,text_rect)
    
    #initialize pygame
    pygame.init()
    
    #set colors
    white = (255,255,255)
    yellow = (255, 255, 102)
    black = (0,0,0)
    red = (255,0,0)
    green = (34,139,34)
    pink = (219,112,147)
    blue = (100,105,255)
    purple = (147,112,219)
    orange = (255,165,0)
    tomato = (255,99,71)
    darkbrown = (101,56,33)

    #set variables
    speedX = 0
    speedY = 0
    blockSize = 10
    snakeList = []
    snakeLength = 1
    FPS = 10
    font = pygame.font.SysFont("comicsansms",25)
    largefont = pygame.font.SysFont("comicsansms",40)
    background_img = pygame.image.load("grass1.bmp")
    wood_sign = pygame.image.load("wood_sign1.bmp")
    gameover = pygame.image.load("gameover.png")
    eatSound = pygame.mixer.Sound("eat.wav")
    hitSound = pygame.mixer.Sound("youlose.wav")
    direction = "up"

    #create window
    width = 500
    height = 500
    gameDisplay = pygame.display.set_mode((width,height))
    pygame.display.set_caption('SnakeBite')

    #call and generate food randomly
    peach = Food(gameDisplay,width,height,blockSize)
    peachX,peachY = peach.newPos(blockSize)

    clock = pygame.time.Clock()

    playing = True
    while playing:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                playing = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    speedX = -blockSize
                    speedY = 0
                    direction = "left"
                elif event.key == pygame.K_RIGHT:
                    speedX = blockSize
                    speedY = 0
                    direction = "right"
                elif event.key == pygame.K_UP:
                    speedY = -blockSize
                    speedX = 0
                    direction = "up"
                elif event.key == pygame.K_DOWN:
                    speedY = blockSize
                    speedX = 0
                    direction = "down"

        width += speedX*2
        height += speedY*2
                
        #set background color
        #gameDisplay.fill(black)
        gameDisplay.blit(background_img,[0,0])
        gameDisplay.blit(wood_sign,[-10,-40])

        #draw food
        peach.drawFood(red)

        #draw a snake
        player = Snake(gameDisplay,width,height,snakeList)
        player.drawSnake(green,direction,snakeLength)
        lead_x,lead_y = player.snakePos()

        #append segments added to the list to increase the snake's length   
        snakeHead = [lead_x, lead_y]
        snakeList.append(snakeHead)
        if len(snakeList) > snakeLength:
            del snakeList[0]
            

        #when the peach is eaten
        if peach.isEaten(player):
            peachX,peachY = peach.newPos(blockSize)
            snakeLength += 1
            eatSound.play()

        #add segments  
        player.addSegment(green,pink,blue,direction,snakeLength)
        
        #when the snake hit itself or/and screen boudaries
        if player.collisionCheck():
            hitSound.play()
            playing = False
            gameDisplay.blit(gameover,[110,180]) #Game over picture
            
            message("CLICK ANYWHERE TO PLAY AGAIN!",red,250,310,font)
                    
        message("Age: " + str(snakeLength-1),black,75,40,font)
        clock.tick(FPS)
##        for i in range(0,100,10):
##            if (snakeLength-1) == i:
                #FPS =
        if snakeLength - 1 < 5:
            message('Newborn',green,78,75,font)
        elif 5 <= snakeLength - 1 < 10:
            FPS = 15
            message('Snakelet',pink,78,75,font)
        elif 10 <= snakeLength - 1 < 15:
            FPS = 20
            message('Teenie',yellow,78,75,font)
        elif 15 <= snakeLength - 1 < 20:
            FPS = 25
            message('Half-adult',purple,78,75,font)
        elif 20 <= snakeLength - 1 < 40:
            FPS = 30
            message('Real adult',orange,78,75,font)
        elif 40 <= snakeLength - 1 < 50:
            FPS = 35
            message('Middle-age',black,78,75,font)
        elif 50 <= snakeLength - 1 < 100:
            FPS = 40
            message("Senior",tomato,78,75,font)
            
        pygame.display.update()
        
    #exit/play again 
    while True:
        pygame.init()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                main()
    

game()
