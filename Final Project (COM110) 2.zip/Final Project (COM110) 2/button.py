# buttonClass.py
from graphics import *

class Button:

    """A button is a labeled rectangle in a window.
    It is enabled or disabled with the activate()
    and deactivate() methods. The clicked(pt) method
    returns True if and only if the button is enabled and pt is inside it."""

    def __init__(self, win, center, width, height, words):
        """ Creates a rectangular button, eg:
        qb = Button(myWin, centerPoint, width, height, 'Quit') """ 
        w,h = width/2.0, height/2.0
        x,y = center.getX(), center.getY()
        self.xmax, self.xmin = x+w, x-w 
        self.ymax, self.ymin = y+h, y-h
        p1 = Point(self.xmin, self.ymin)
        p2 = Point(self.xmax, self.ymax)
        self.rect = Rectangle(p1,p2)
        self.rect.setFill(color_rgb(255, 240, 214))
        self.rect.draw(win)
        self.label = Text(center,words)
        self.label.draw(win)
        self.activate() 
        
    def getLabel(self):
        """Returns the label string of this button."""
        return self.label.getText()

    def activate(self):
        """Sets this button to 'active'."""
        self.label.setFill('black') 
        self.rect.setWidth(2)       
        self.active = True          

    def deactivate(self):
        """Sets this button to 'inactive'."""
        self.label.setFill("darkgray")  
        self.rect.setWidth(2)           
        self.active = False             

    def isClicked(self, pt):
        """Returns true if button active and Point p is inside"""
        return(self.active and (pt.getX() > self.xmin and pt.getX() < self.xmax and pt.getY() > self.ymin and pt.getY() < self.ymax))

    def undraw(self):
        self.rect.undraw()
        self.label.undraw()
    

"""def main():
    win = GraphWin("Button", 400, 400)
    win.setCoords(0, 0, 400, 400)
    win.setBackground('yellow')
    
    rollDice = Button(win, Point(200, 150), 100, 40, 'Roll Dice')
    rollDice.activate()
    quitButton = Button(win, Point(200, 100), 50, 25, 'Quit')
    quitButton.deactivate()

    pt = win.getMouse()
    while not quitButton.isClicked(pt):
        if rollDice.isClicked(pt):
            quitButton.activate()
        pt = win.getMouse()
            
    win.close() 
    
if __name__ == "__main__": 
    main()"""

