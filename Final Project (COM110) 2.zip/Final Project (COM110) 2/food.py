import pygame
import random
import snake
pygame.init()

class Food:
    """docstring"""
    
    def __init__(self,surface,x,y,blockSize):
        self.w = x
        self.h = y
        self.blockSize = 10
        self.surface = surface
        self.image = pygame.image.load("peach.png")

    def drawFood(self,color):
        '''
        self.food = pygame.Rect(self.x, self.y, self.blockSize,self.blockSize)
        pygame.draw.rect(self.surface,color,self.food)
        '''
        self.surface.blit(self.image,[self.x,self.y])

    def calculateSides(self,blockSize):
        self.leftSide = self.x
        self.topSide = self.y
        self.rightSide = self.x+ blockSize
        self.bottomSide = self.y + blockSize

    def isCollision(self,obj):
        self.calculateSides(self.blockSize)
        obj.calculateSides(obj.blockSize)
    
        vertical = (self.leftSide >= obj.leftSide and self.leftSide <= obj.rightSide) or (self.rightSide >= obj.leftSide and self.rightSide <= obj.rightSide)
        horizontal = (self.topSide <= obj.bottomSide and self.topSide >= obj.topSide) or (self.bottomSide <= obj.bottomSide and self.bottomSide >= obj.topSide)

        if (self.topSide == obj.bottomSide or self.rightSide == obj.leftSide) or (self.topSide == obj.bottomSide or self.leftSide == obj.rightSide) or (self.bottomSide == obj.topSide or self.leftSide == obj.rightSide) or (self.bottomSide == obj.topSide or self.rightSide == obj.leftSide):
            return False
        return vertical and horizontal

    def isEaten(self,head):
        return self.isCollision(head)

    def newPos(self,blockSize):
        self.x = random.randrange(130,self.w - self.blockSize,self.blockSize)
        self.y = random.randrange(100,self.h - self.blockSize,self.blockSize)
        return self.x, self.y
            
            
        
