import pygame
pygame.init()

class Snake:
    """docstring"""
    
    def __init__(self,surface, screen_width,screen_height,snakeList):
        self.x = screen_width/2
        self.y = screen_height/2
        self.width = 10
        self.height = 10
        self.surface = surface
        self.blockSize = 10
        self.snakeList = snakeList
        self.head_img = pygame.image.load("snake_head.png")
        self.body_img = pygame.image.load("snake_body.png")
        self.tail_img = pygame.image.load("snake_tail.png")

    def drawSnake(self,color,direction,snakeLength):
        '''
        self.head = pygame.Rect(self.x,self.y,self.width,self.height)
        pygame.draw.rect(self.surface,color,self.head)
        '''
        if snakeLength == 1:
            if direction == "right":
                head_img = pygame.transform.rotate(self.head_img,270)
            elif direction == "left":
                head_img = pygame.transform.rotate(self.head_img,90)
            elif direction == "up":
                head_img = self.head_img
            elif direction == "down":
                head_img = pygame.transform.rotate(self.head_img,180)
                
            self.surface.blit(head_img,[self.x,self.y])
        
    def calculateSides(self,blockSize):
        self.leftSide = self.x
        self.topSide = self.y
        self.rightSide = self.x + blockSize
        self.bottomSide = self.y + blockSize
     
    def addSegment(self,color1,color2,color3,direction,snakeLength):
        if snakeLength == 2:
            #draw head and tail 
            if direction == "right":
                head_img = pygame.transform.rotate(self.head_img,270)
                tail_img = pygame.transform.rotate(self.tail_img,270)
                
            elif direction == "left":
                head_img = pygame.transform.rotate(self.head_img,90)
                tail_img = pygame.transform.rotate(self.tail_img,90)
            elif direction == "up":
                head_img = self.head_img
                tail_img = self.tail_img
            elif direction == "down":
                head_img = pygame.transform.rotate(self.head_img,180)
                tail_img = pygame.transform.rotate(self.tail_img,180)
                
            self.surface.blit(head_img,[self.snakeList[-1][0],self.snakeList[-1][1]])
            self.surface.blit(tail_img,[self.snakeList[0][0],self.snakeList[0][1]])
        
        elif snakeLength>2:
        #draw the snake head
        #pygame.draw.rect(self.surface,color1,[self.snakeList[-1][0],self.snakeList[-1][1],self.blockSize,self.blockSize])
            if direction == "right":
                head_img = pygame.transform.rotate(self.head_img,270)
                tail_img = pygame.transform.rotate(self.tail_img,270)
            elif direction == "left":
                head_img = pygame.transform.rotate(self.head_img,90)
                tail_img = pygame.transform.rotate(self.tail_img,90)
            elif direction == "up":
                head_img = self.head_img
                tail_img = self.tail_img
            elif direction == "down":
                head_img = pygame.transform.rotate(self.head_img,180)
                tail_img = pygame.transform.rotate(self.tail_img,180)
                
            self.surface.blit(head_img,[self.snakeList[-1][0],self.snakeList[-1][1]])
            self.surface.blit(tail_img,[self.snakeList[0][0],self.snakeList[0][1]])     
            
            #draw the snake tail
            #pygame.draw.rect(self.surface,color3,[self.snakeList[0][0],self.snakeList[0][1],self.blockSize,self.blockSize
            
            #draw the body
            for XnY in self.snakeList[1:-1]:
                #pygame.draw.rect(self.surface,color2,[XnY[0],XnY[1],self.blockSize,self.blockSize])
                if direction == "right":
                    body_img = pygame.transform.rotate(self.body_img,270)
                elif direction == "left":
                    body_img = pygame.transform.rotate(self.body_img,90)
                elif direction == "up":
                    body_img = self.body_img
                elif direction == "down":
                    body_img = pygame.transform.rotate(self.body_img,180)
                self.surface.blit(body_img,[XnY[0],XnY[1]])
            
    def snakePos(self):
        return self.x, self.y

    def collisionCheck(self):
        #collision with screen boundaries
        if self.y < 1 or self.y > 499 - self.height or self.x < 1 or self.x > 499 - self.width:
            return True
        #collision itself
        for XnY in self.snakeList[1:-1]:
            if self.snakeList[-1][0] == XnY[0] and self.snakeList[-1][1] == XnY[1]:
                return True
            
